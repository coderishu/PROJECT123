package com.example.ishumishra97.internathmtechnologies;

/**
 * Created by ishu.mishra97 on 8/3/2016.
 */
public class DataModel {

    public int icon;
    public String name;

    // Constructor.
    public DataModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}
